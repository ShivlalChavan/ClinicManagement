package com.example.clinicenrolment.model

import java.io.Serializable

class PatientBase (

    var patientList : ArrayList<PatientDetail>

):Serializable