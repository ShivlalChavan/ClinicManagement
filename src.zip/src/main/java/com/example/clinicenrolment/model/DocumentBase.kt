package com.example.clinicenrolment.model

import java.io.Serializable

class DocumentBase (

   val documentList:ArrayList<DocumentModel>

):Serializable