package com.example.clinicenrolment.model

import java.io.Serializable

class MedicineBase (

    val medicineList : ArrayList<Medicine>

):Serializable