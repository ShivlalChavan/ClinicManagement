package com.example.clinicenrolment.model

import java.io.Serializable

class DocumentModel (

    var patientId:String="",
    var documentId:String="",
    var documentName:String="",
    var documentPath:String="",
    var date:String=""

):Serializable