package com.example.clinicenrolment.model

import java.io.Serializable

class ReasonBase (
    val reasonList : ArrayList<Reason>
):Serializable