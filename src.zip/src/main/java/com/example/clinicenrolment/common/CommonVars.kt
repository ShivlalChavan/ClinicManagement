package com.example.clinicenrolment.common

import android.content.Context
import android.os.Environment
import android.os.Environment.getExternalStorageDirectory


class CommonVars {



}