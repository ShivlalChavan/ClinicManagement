package com.example.clinicenrolment.Interface

interface FragmentBackPressed {

    abstract fun onBackKeyPressed()
}